package org.example.database_crud;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import javafx.animation.*;
import javafx.util.Duration;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.effect.DropShadow;
import javafx.scene.paint.Color;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class Main extends Application {

    @Override
    public void start(Stage primaryStage) {
        // TableView with drop shadow
        TableView<User> tableView = new TableView<>();
        tableView.setStyle("-fx-background-color: rgba(173, 216, 230, 0.7); -fx-text-fill: #000080;");
        tableView.setEffect(new DropShadow(15, Color.DARKBLUE));

        // Styled text fields
        TextField idField = createStyledTextField("ID");
        TextField nameField = createStyledTextField("Name");
        TextField emailField = createStyledTextField("Email");

        // Styled buttons with animations
        Button insertButton = createStyledButton("Insert", "linear-gradient(to bottom right, #FF69B4, #FF1493)");
        Button updateButton = createStyledButton("Update", "linear-gradient(to bottom right, #FF1493, #C71585)");
        Button deleteButton = createStyledButton("Delete", "linear-gradient(to bottom right, #FF69B4, #DB7093)");
        Button viewButton = createStyledButton("View Data", "linear-gradient(to bottom right, #FF1493, #FF69B4)");

        // Input fields layout
        HBox inputBox = new HBox(15, idField, nameField, emailField);
        inputBox.setAlignment(Pos.CENTER);
        inputBox.setPadding(new Insets(10));
        inputBox.setEffect(new DropShadow(10, Color.LIGHTGRAY));

        // Buttons layout
        HBox buttonBox = new HBox(15, insertButton, updateButton, deleteButton, viewButton);
        buttonBox.setAlignment(Pos.CENTER);
        buttonBox.setPadding(new Insets(20));
        buttonBox.setEffect(new DropShadow(10, Color.LIGHTGRAY));

        // Main layout with gradient background and spacing
        VBox layout = new VBox(20, tableView, inputBox, buttonBox);
        layout.setStyle("-fx-background-color: linear-gradient(to bottom right, #87CEEB, #4169E1); -fx-padding: 20;");
        layout.setAlignment(Pos.CENTER);

        Scene scene = new Scene(layout, 850, 600);
        scene.getStylesheets().add(getClass().getResource("/styles.css").toExternalForm());

        // Set up the stage
        primaryStage.setTitle("CRUD Application - Moses - 2025-02-21");
        primaryStage.setScene(scene);
        primaryStage.show();

        // Set up the table and load data
        UserController.setupTable(tableView);
        loadData(tableView);

        // Button actions with animations
        insertButton.setOnAction(e -> {
            String name = nameField.getText();
            String email = emailField.getText();
            new Thread(() -> {
                try (Connection conn = DatabaseConnection.getConnection()) {
                    String sql = "INSERT INTO users (name, email) VALUES (?, ?)";
                    try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                        pstmt.setString(1, name);
                        pstmt.setString(2, email);
                        pstmt.executeUpdate();
                        Platform.runLater(() -> {
                            loadData(tableView);
                            showSuccessAnimation(insertButton);
                        });
                    }
                } catch (SQLException ex) {
                    ex.printStackTrace();
                    Platform.runLater(() -> showAlert("Error", "Failed to insert data: " + ex.getMessage()));
                }
            }).start();
        });

        updateButton.setOnAction(e -> {
            int id = Integer.parseInt(idField.getText());
            String name = nameField.getText();
            String email = emailField.getText();
            new Thread(() -> {
                try (Connection conn = DatabaseConnection.getConnection()) {
                    String sql = "UPDATE users SET name=?, email=? WHERE id=?";
                    try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                        pstmt.setString(1, name);
                        pstmt.setString(2, email);
                        pstmt.setInt(3, id);
                        pstmt.executeUpdate();
                        Platform.runLater(() -> {
                            loadData(tableView);
                            showSuccessAnimation(updateButton);
                        });
                    }
                } catch (SQLException ex) {
                    ex.printStackTrace();
                    Platform.runLater(() -> showAlert("Error", "Failed to update data: " + ex.getMessage()));
                }
            }).start();
        });

        deleteButton.setOnAction(e -> {
            int id = Integer.parseInt(idField.getText());
            new Thread(() -> {
                try (Connection conn = DatabaseConnection.getConnection()) {
                    String sql = "DELETE FROM users WHERE id=?";
                    try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                        pstmt.setInt(1, id);
                        pstmt.executeUpdate();
                        Platform.runLater(() -> {
                            loadData(tableView);
                            showSuccessAnimation(deleteButton);
                        });
                    }
                } catch (SQLException ex) {
                    ex.printStackTrace();
                    Platform.runLater(() -> showAlert("Error", "Failed to delete data: " + ex.getMessage()));
                }
            }).start();
        });

        viewButton.setOnAction(e -> loadData(tableView));
    }

    private TextField createStyledTextField(String promptText) {
        TextField textField = new TextField();
        textField.setPromptText(promptText);
        textField.getStyleClass().add("styled-text-field");
        textField.setEffect(new DropShadow(8.0, Color.LIMEGREEN));
        return textField;
    }

    private Button createStyledButton(String text, String gradient) {
        Button button = new Button(text);
        button.getStyleClass().add("styled-button");
        button.setStyle("-fx-background-color: " + gradient + ";");
        button.setEffect(new DropShadow(10, Color.GRAY));

        ScaleTransition scaleTransition = new ScaleTransition(Duration.millis(200), button);
        scaleTransition.setToX(1.1);
        scaleTransition.setToY(1.1);

        button.setOnMouseEntered(e -> scaleTransition.playFromStart());
        button.setOnMouseExited(e -> {
            scaleTransition.setToX(1.0);
            scaleTransition.setToY(1.0);
            scaleTransition.playFromStart();
        });

        return button;
    }

    private void showSuccessAnimation(Button button) {
        ParallelTransition pt = new ParallelTransition();

        FadeTransition ft = new FadeTransition(Duration.millis(300), button);
        ft.setFromValue(1.0);
        ft.setToValue(0.3);
        ft.setCycleCount(2);
        ft.setAutoReverse(true);

        ScaleTransition st = new ScaleTransition(Duration.millis(300), button);
        st.setFromX(1.0);
        st.setFromY(1.0);
        st.setToX(1.2);
        st.setToY(1.2);
        st.setCycleCount(2);
        st.setAutoReverse(true);

        RotateTransition rt = new RotateTransition(Duration.millis(300), button);
        rt.setByAngle(360);
        rt.setCycleCount(1);

        pt.getChildren().addAll(ft, st, rt);
        pt.play();
    }

    private void loadData(TableView<User> tableView) {
        new Thread(() -> {
            javafx.collections.ObservableList<User> users = null;
            try {
                users = UserController.getUsers();
            } catch (SQLException e) {
                throw new RuntimeException(e);
            }
            javafx.collections.ObservableList<User> finalUsers = users;
            Platform.runLater(() -> {
                tableView.setItems(finalUsers);
                FadeTransition ft = new FadeTransition(Duration.millis(500), tableView);
                ft.setFromValue(0.5);
                ft.setToValue(1.0);
                ft.play();
            });
        }).start();
    }

    private void showAlert(String title, String content) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.getDialogPane().setEffect(new DropShadow(10, Color.RED));
        alert.showAndWait();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
