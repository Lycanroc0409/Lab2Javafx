module org.example.database_crud {
    requires javafx.controls;
    requires javafx.fxml;

    requires com.dlsc.formsfx;
    requires java.sql;
    requires mysql.connector.java;

    opens org.example.database_crud to javafx.fxml;
    exports org.example.database_crud;
}